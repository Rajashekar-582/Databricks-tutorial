# Databricks notebook source
# MAGIC %md
# MAGIC step 1 - create a folder structure

# COMMAND ----------

spark.sql("CREATE SCHEMA IF NOT EXISTS dbwork1.project")
# Tables will be created as:
# dbwork1.project.source
# dbwork1.project.destination

# COMMAND ----------

# MAGIC %sql SHOW CATALOGS

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VOLUME IF NOT EXISTS dbwork1.default.dbwork1_volume;

# COMMAND ----------

# MAGIC
# MAGIC %sql SHOW SCHEMAS IN dbwork1
# MAGIC

# COMMAND ----------

# MAGIC  %sql SHOW VOLUMES IN dbwork1.default
# MAGIC

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/dbwork1/default/project/Source")
dbutils.fs.mkdirs("/Volumes/dbwork1/default/project/Destination")

# COMMAND ----------

dbutils.fs.ls("/Volumes/dbwork1/default/project")

# COMMAND ----------

# MAGIC %md
# MAGIC uploaded the files into source folder

# COMMAND ----------

# MAGIC %md
# MAGIC step2 - load csv files

# COMMAND ----------

dbutils.fs.ls("/Volumes/dbwork1/default/project/Source")

# COMMAND ----------

orders_data=spark.read.csv("/Volumes/dbwork1/default/project/Source/Orders.csv",header=True,inferSchema=True)
order_item_data=spark.read.csv("/Volumes/dbwork1/default/project/Source/Order_Item.csv",header=True,inferSchema=True)
product_data=spark.read.csv("/Volumes/dbwork1/default/project/Source/Products.csv",header=True,inferSchema=True)
categories_data=spark.read.csv("/Volumes/dbwork1/default/project/Source/Categories.csv",header=True,inferSchema=True)


# COMMAND ----------

# MAGIC %md
# MAGIC step 3 - show/verfy data

# COMMAND ----------

orders_data.show()

# COMMAND ----------

order_item_data.show()

# COMMAND ----------

product_data.show()

# COMMAND ----------

categories_data.show()

# COMMAND ----------

# MAGIC %md
# MAGIC step 4 - data transformation
# MAGIC
# MAGIC #Perform inner joins to consolidate sales data with product and category details

# COMMAND ----------


#1. What is the total revenue for each product category?
#2. What is the total revenue for each product?
#3. What is the total revenue for each customer?
#4. What is the total revenue for each day?
#5. What is the total revenue for each month?
#6. What is the total revenue for each quarter?
#7. What is the total revenue for each year?
#8. What is the total revenue for each product category for each day?
#9. What is the total revenue for each product category for each month?
#10. What is the total revenue for each product category for each quarter?
#11. What is the total revenue for each product category for each year?
#12. What is the total revenue for each product for each day?
#13. What is the total revenue for each product for each month?
#14. What is the total revenue for each product for each quarter?
#15. What is the total revenue for each product for each year?
#16. What is the total revenue for each customer for each day?
#17. What is the total revenue for each customer for each month?
#18. What is the total revenue for each customer for each quarter?
#19. What is the total revenue for each customer for each year?
#20. What is the total revenue for each product category for each customer?
#21. What is the total revenue for each product for each customer?
#22. What is the total revenue for each day for each customer?
#23. What is the total revenue for each month for each customer?
#24. What is the total revenue for each quarter for each customer?
#25. What is the total revenue for each year for each customer?
#26. What is the total revenue for each product category for each day for each customer?
#27. What is the total revenue for each product for each day for each customer?
#28. What is the total revenue for each product category for each month for each customer?
#29. What is the total revenue for each product for each month for each customer

# COMMAND ----------

from pyspark.sql.functions import *

joined_data=(
    orders_data.join(order_item_data,"order_id","inner")
    .join(product_data,"product_id","inner")
    .join(categories_data,"category_id","inner")
    .select(
        col("order_id"),
        col("customer_id"),
        col("order_date"),
        col("product_name"),
        col("category_name"),
        col("quantity"),
        col("total_amount")
    )
)

# COMMAND ----------

joined_data.show()

# COMMAND ----------

cust_df=joined_data.groupby('customer_id').agg(sum('quantity').alias('total_quantity'),sum('total_amount').alias('total_amount'))




# COMMAND ----------

cust_df.show()


# COMMAND ----------

joined_data.write.csv("/Volumes/dbwork1/default/project/Destination/sales_report.csv")
cust_df.write.csv("/Volumes/dbwork1/default/project/Destination/customer.csv")
display(joined_data)
display(cust_df)