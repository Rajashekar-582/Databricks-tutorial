# Databricks notebook source
spark.conf.set(
  "fs.azure.account.key.sgrajasheakrblob.blob.core.windows.net",
  "wsX7XqaqmATsyhEZmN6H3o5itDrL2FSV3YOqBBR5WJjjqgicJsg/kiBPFiUe+h5mSBLmV9yG59vk+AStXd9yqA=="
)

# COMMAND ----------

file_path = (
    "wasbs://rajacontainer@sgrajasheakrblob.blob.core.windows.net/"
    "marketing_campaign.csv"
)

# COMMAND ----------

file_path = "wasbs://rajacontainer@sgrajasheakrblob.blob.core.windows.net/marketing_campaign.csv"

df = spark.read \
    .option("header", "true") \
    .option("delimiter", "\t") \
    .option("inferSchema", "true") \
    .csv(file_path)

df.display()


# COMMAND ----------

df1=df.groupby('Education').count()

# COMMAND ----------

df1.display()


# COMMAND ----------

from pyspark.sql.functions import when, col

df3 = df.select(
    when(col('Income') > 500000, 'High-Income')
    .when(col('Income') > 250000, 'Medium-Income')
    .when(col('Income') > 100000, 'Low-Medium Income')
    .otherwise('Low-Income')
    .alias('Income_Category')
)
df3.display()