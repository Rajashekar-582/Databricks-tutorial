# Databricks notebook source
spark.conf.set(
  "fs.azure.account.key.sgrajasheakrblob.blob.core.windows.net",
    "wsX7XqaqmATsyhEZmN6H3o5itDrL2FSV3YOqBBR5WJjjqgicJsg/kiBPFiUe+h5mSBLmV9yG59vk+AStXd9yqA=="

)

# COMMAND ----------

file_path = "wasbs://rajacontainer@sgrajasheakrblob.blob.core.windows.net/marketing_campaign.csv"

df = (
    spark.read
    .option("header", "true")
    .option("delimiter", "\t")
    .option("inferSchema", "true")
    .csv(file_path)
)

display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS dbwork1.marketing;
# MAGIC USE dbwork1.marketing;
# MAGIC

# COMMAND ----------

df.write \
  .format("delta") \
  .mode("overwrite") \
  .saveAsTable("dbwork1.marketing.customers_raw")


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM dbwork1.marketing.customers_raw;

# COMMAND ----------

from pyspark.sql.functions import col, year, current_date

df_enriched = (
    spark.table("dbwork1.marketing.customers_raw")
    .withColumn("Age", year(current_date()) - col("Year_Birth"))
    .withColumn("Total_Spend",
        col("MntWines") +
        col("MntFruits") +
        col("MntMeatProducts") +
        col("MntFishProducts") +
        col("MntSweetProducts") +
        col("MntGoldProds")
    )
)

display(df_enriched)

# COMMAND ----------

df_enriched.write.option("mergeSchema", "true") \
  .mode("overwrite") \
  .format("delta") \
  .saveAsTable("dbwork1.marketing.customers_enriched")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   COUNT(*) AS total_customers,
# MAGIC   SUM(Response) AS responded_customers,
# MAGIC   ROUND(SUM(Response) * 100 / COUNT(*), 2) AS success_rate
# MAGIC FROM dbwork1.marketing.customers_enriched;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   Education,
# MAGIC   COUNT(*) AS customers,
# MAGIC   ROUND(AVG(Income), 0) AS avg_income
# MAGIC FROM dbwork1.marketing.customers_enriched
# MAGIC GROUP BY Education
# MAGIC ORDER BY avg_income DESC;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   Marital_Status,
# MAGIC   ROUND(AVG(Total_Spend), 0) AS avg_spend
# MAGIC FROM dbwork1.marketing.customers_enriched
# MAGIC GROUP BY Marital_Status
# MAGIC ORDER BY avg_spend DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW dbwork1.marketing.customer_segments AS
# MAGIC SELECT *,
# MAGIC   CASE
# MAGIC     WHEN Income >= 80000 THEN 'High Income'
# MAGIC     WHEN Income BETWEEN 40000 AND 79999 THEN 'Middle Income'
# MAGIC     ELSE 'Low Income'
# MAGIC   END AS income_segment
# MAGIC FROM dbwork1.marketing.customers_enriched;

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE dbwork1.marketing.customers_enriched
# MAGIC ZORDER BY (Income, Education);

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY dbwork1.marketing.customers_enriched;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO dbwork1.marketing.customers_enriched t
# MAGIC USING dbwork1.marketing.customers_raw s
# MAGIC ON t.ID = s.ID
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     t.Year_Birth = s.Year_Birth,
# MAGIC     t.Education = s.Education,
# MAGIC     t.Marital_Status = s.Marital_Status,
# MAGIC     t.Income = s.Income,
# MAGIC     t.Kidhome = s.Kidhome,
# MAGIC     t.Teenhome = s.Teenhome,
# MAGIC     t.Age = year(current_date()) - s.Year_Birth,
# MAGIC     t.Total_Spend =
# MAGIC       s.MntWines + s.MntFruits + s.MntMeatProducts +
# MAGIC       s.MntFishProducts + s.MntSweetProducts + s.MntGoldProds
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (
# MAGIC     ID, Year_Birth, Education, Marital_Status, Income,
# MAGIC     Kidhome, Teenhome, Age, Total_Spend
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     s.ID, s.Year_Birth, s.Education, s.Marital_Status, s.Income,
# MAGIC     s.Kidhome, s.Teenhome,
# MAGIC     year(current_date()) - s.Year_Birth,
# MAGIC     s.MntWines + s.MntFruits + s.MntMeatProducts +
# MAGIC     s.MntFishProducts + s.MntSweetProducts + s.MntGoldProds
# MAGIC   );
# MAGIC

# COMMAND ----------

feature_cols = [
    "Age", "Income", "Total_Spend",
    "NumWebPurchases", "NumStorePurchases",
    "NumDealsPurchases"
]

df_ml = df_enriched.select(feature_cols + ["Response"])
display(df_ml)

# COMMAND ----------

from pyspark.ml.feature import Imputer

imputer = Imputer(
    inputCols=feature_cols,
    outputCols=feature_cols
).setStrategy("median")

df_imputed = imputer.fit(df_ml).transform(df_ml)

train_df = assembler.transform(df_imputed).select("features", "Response")

# COMMAND ----------

from pyspark.ml.classification import LogisticRegression

lr = LogisticRegression(labelCol="Response")
model = lr.fit(train_df)


# COMMAND ----------

from pyspark.sql.functions import col, year, current_date

# Load from your enriched table (or build Age/Total_Spend if needed)
base = spark.table("dbwork1.marketing.customers_enriched")

# Ensure Response is numeric
df_ml = (base
         .withColumn("Response", col("Response").cast("int"))
         .select(
             col("Age").cast("double"),
             col("Income").cast("double"),
             col("Total_Spend").cast("double"),
             col("NumWebPurchases").cast("double"),
             col("NumStorePurchases").cast("double"),
             col("NumDealsPurchases").cast("double"),
             col("Response").alias("label")
         )
)

display(df_ml)

# COMMAND ----------

train_df, test_df = df_ml.randomSplit([0.8, 0.2], seed=42)

# COMMAND ----------

from pyspark.ml import Pipeline
from pyspark.ml.feature import Imputer, VectorAssembler
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator

feature_cols = ["Age","Income","Total_Spend","NumWebPurchases","NumStorePurchases","NumDealsPurchases"]

imputer = Imputer(
    inputCols=feature_cols,
    outputCols=[c + "_imp" for c in feature_cols]
).setStrategy("median")

assembler = VectorAssembler(
    inputCols=[c + "_imp" for c in feature_cols],
    outputCol="features"
)

lr = LogisticRegression(featuresCol="features", labelCol="label")

pipeline = Pipeline(stages=[imputer, assembler, lr])
model = pipeline.fit(train_df)
pred = model.transform(test_df)

# COMMAND ----------

evaluator_roc = BinaryClassificationEvaluator(labelCol="label", rawPredictionCol="rawPrediction", metricName="areaUnderROC")
evaluator_pr  = BinaryClassificationEvaluator(labelCol="label", rawPredictionCol="rawPrediction", metricName="areaUnderPR")

auc_roc = evaluator_roc.evaluate(pred)
auc_pr  = evaluator_pr.evaluate(pred)

print("AUC-ROC:", auc_roc)
print("AUC-PR :", auc_pr)


# COMMAND ----------

from pyspark.sql.functions import expr

# accuracy
acc = pred.select(expr("AVG(CASE WHEN prediction = label THEN 1.0 ELSE 0.0 END) AS accuracy")).first()["accuracy"]
print("Accuracy:", acc)

# confusion matrix
pred.groupBy("label","prediction").count().orderBy("label","prediction").show()

# COMMAND ----------

df_cluster = (base
    .select(
        col("Age").cast("double"),
        col("Income").cast("double"),
        col("Total_Spend").cast("double"),
        col("NumWebPurchases").cast("double"),
        col("NumStorePurchases").cast("double"),
        col("NumDealsPurchases").cast("double")
    )
)

# COMMAND ----------

from pyspark.ml.clustering import KMeans
from pyspark.ml.evaluation import ClusteringEvaluator

cluster_cols = ["Age","Income","Total_Spend","NumWebPurchases","NumStorePurchases","NumDealsPurchases"]

imputer_c = Imputer(
    inputCols=cluster_cols,
    outputCols=[c + "_imp" for c in cluster_cols]
).setStrategy("median")

assembler_c = VectorAssembler(
    inputCols=[c + "_imp" for c in cluster_cols],
    outputCol="features"
)

kmeans = KMeans(k=4, seed=42, featuresCol="features", predictionCol="cluster")

cluster_pipe = Pipeline(stages=[imputer_c, assembler_c, kmeans])
cluster_model = cluster_pipe.fit(df_cluster)
clustered = cluster_model.transform(df_cluster)

# COMMAND ----------

ce = ClusteringEvaluator(featuresCol="features", predictionCol="cluster", metricName="silhouette")
sil = ce.evaluate(clustered)
print("Silhouette:", sil)

clustered.groupBy("cluster").count().orderBy("cluster").show()

# COMMAND ----------

scores = []
for k in [2,3,4,5,6,7,8]:
    km = KMeans(k=k, seed=42, featuresCol="features", predictionCol="cluster")
    pipe = Pipeline(stages=[imputer_c, assembler_c, km])
    m = pipe.fit(df_cluster)
    out = m.transform(df_cluster)
    s = ce.evaluate(out)
    scores.append((k, s))

scores

# COMMAND ----------

from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

# Reuse 'pipeline' from section 1 (imputer + assembler + lr)

paramGrid = (ParamGridBuilder()
             .addGrid(lr.regParam, [0.0, 0.01, 0.1])
             .addGrid(lr.elasticNetParam, [0.0, 0.5, 1.0])
             .addGrid(lr.maxIter, [20, 50])
             .build())

cv = CrossValidator(
    estimator=pipeline,
    estimatorParamMaps=paramGrid,
    evaluator=BinaryClassificationEvaluator(labelCol="label", rawPredictionCol="rawPrediction", metricName="areaUnderROC"),
    numFolds=3,
    parallelism=2
)

cvModel = cv.fit(train_df)
cvPred = cvModel.transform(test_df)

print("Tuned AUC-ROC:", evaluator_roc.evaluate(cvPred))
print("Tuned AUC-PR :", evaluator_pr.evaluate(cvPred))

# COMMAND ----------

# MAGIC %sql
# MAGIC show volumes

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VOLUME dbwork1.marketing.ml_models;

# COMMAND ----------

model_path = "/Volumes/dbwork1/marketing/ml_models/response_lr_pipeline"

cvModel.write().overwrite().save(model_path)

# COMMAND ----------

import mlflow
import mlflow.spark

with mlflow.start_run(run_name="marketing_response_lr"):
    mlflow.log_metric("auc_roc", auc_roc)
    mlflow.log_metric("auc_pr", auc_pr)
    mlflow.spark.log_model(cvModel, "model")


# COMMAND ----------

import mlflow
import mlflow.spark

run = mlflow.start_run(run_name="marketing_response_lr")

mlflow.log_metric("auc_roc", auc_roc)
mlflow.log_metric("auc_pr", auc_pr)
mlflow.spark.log_model(cvModel, "model")

run_id = run.info.run_id
mlflow.end_run()

model_uri = f"runs:/{run_id}/model"
mlflow.register_model(model_uri, "dbwork1.marketing.response_model")


# COMMAND ----------

print(model_uri)  # should look like runs:/<run_id>/model

# COMMAND ----------

with mlflow.start_run() as run:
    run_id = run.info.run_id
    ...
# use run_id here safely


# COMMAND ----------

